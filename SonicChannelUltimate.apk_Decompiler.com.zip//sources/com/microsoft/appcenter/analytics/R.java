package com.microsoft.appcenter.analytics;

public final class R {
}
