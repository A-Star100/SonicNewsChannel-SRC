package com.microsoft.appcenter.crashes;

public final class R {
}
