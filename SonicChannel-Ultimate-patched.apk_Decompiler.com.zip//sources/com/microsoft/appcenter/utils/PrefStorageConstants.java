package com.microsoft.appcenter.utils;

public class PrefStorageConstants {
    public static final String ALLOWED_NETWORK_REQUEST = "allowedNetworkRequests";
    public static final String KEY_ENABLED = "enabled";
    public static final String KEY_INSTALL_ID = "installId";
}
